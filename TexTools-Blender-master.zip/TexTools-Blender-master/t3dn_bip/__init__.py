'''Load image previews in parallel and in any resolution. Supports BIP files.'''

__version__ = '1.0.8.1'
